<?php
/**
 * Created by PhpStorm.
 * User: amzad
 * Date: 23/03/14
 * Time: 12:06
 */
?>

<!DOCTYPE html>

<style>

html {
    background: url(http://www.energycentric.co.uk/wp-content/uploads/2010/08/electric.jpg) no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
    }
    .header_resize {
    margin: 0 auto;
        padding: 10px 70px 10px 70px;
        width: 870px;
        background: gray;
    }
</style>

<html>
<head>
    <title></title>
    <meta http-equiv="refresh" content="2000; url=http://mjamjad.acnshop.eu/default.asp?CO_LA=GB_EN" />
</head>
<body>


<div class="header_resize" >
    <iframe width="870" height="650" src="//www.youtube.com/embed/Ye98lZGwTJU" frameborder="0" allowfullscreen></iframe>
</div>



</body>
</html>



