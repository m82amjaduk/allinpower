<!DOCTYPE html>

<style>

    html {
        background: url(http://www.energycentric.co.uk/wp-content/uploads/2010/08/electric.jpg) no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
    }
    .header_resize {
        margin: 0 auto;
        padding: 10px 70px 10px 70px;
        width: 370px;
        background: gray;
    }
</style>

<html>
<head>
    <title></title>
    <meta http-equiv="refresh" content="2000; url=http://mjamjad.acnshop.eu/default.asp?CO_LA=GB_EN" />
</head>
<body>


<div class="header_resize" >
    <a href="/"> <img src="http://allinpower.co.uk/img/logo.png" width="100%" /> </a>
    <a href="http://mjamjad.acnshop.eu/default.asp?CO_LA=GB_EN"> ACN Shop </a><br /><br />

    <a href="https://myacn.acninc.com/MyACN/homePage.do">Admin</a><br /><br />

    <a href="http://acneuro.co.uk">Online Registration</a> <br /> <br />
    <a href="http://first-utility.force.com/signup">Apply For License</a> <br />


    <a href="http://firstutility.mindflash.com"> Gass ELE Certificate </a> <br /> <br />


    <a href="https://myacn.acninc.com/RetrievePwd/enterRetrivePwd.do?ctry_lang=GB_EN">First Time Login</a><br />


    <a href="/videos/"> BusinessPresentation </a>  <br />

    sales.admin@first-utility.com  <br />
    uk_helpdesk@acneuro.com <br />
    020 3608 5052 <br />


    <a href="https://myacn.acninc.com/MyACN/RAPDFDownload.do">Manual registation Form </a> <br / >

    <a href="https://www.youtube.com/watch?v=Ye98lZGwTJU">Business Oppertunity </a>  <br />

</div>



</body>
</html>



